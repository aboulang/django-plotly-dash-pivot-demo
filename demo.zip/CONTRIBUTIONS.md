## Contributions

Contributions, under the same MIT license as the repository, are most welcome.

See the [development](https://django-plotly-dash.readthedocs.io/en/latest/development.html) section of
the documentation for details on how to build, test and document contributions.

Once ready, submit a pull request to the [main repository](https://github.com/GibbsConsulting/django-plotly-dash).

Unless you request otherwise, you will be added to the list of contributors below. If you're not on the list
and think you should be, please send an email to <codebase@gibbsconsulting.ca>

## Contributors

Thanks to the following people:

[delsim](https://github.com/delsim)

[weber-s](https://github.com/weber-s)

[eddy-obj](https://github.com/eddy-ojb)

[brylie](https://github.com/brylie)

[robd003](https://github.com/robd003)

[dwinston](https://github.com/dwinston)

[gianlucasalvato](https://github.com/gianlucasalvato)

[tiagoslg](https://https://github.com/tiagoslg)
